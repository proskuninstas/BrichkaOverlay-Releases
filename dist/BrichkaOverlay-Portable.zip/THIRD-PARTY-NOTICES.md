# Third party components

LibreHardwareMonitor 0.9.6: https://github.com/LibreHardwareMonitor/LibreHardwareMonitor (MPL-2.0). Unmodified upstream binary. Source and license: https://github.com/LibreHardwareMonitor/LibreHardwareMonitor/tree/v0.9.6

The required official release dependency DLLs are distributed unchanged:

- HidSharp 2.6.4, Apache-2.0: https://www.nuget.org/packages/HidSharp/2.6.4
- DiskInfoToolkit 1.1.2, MPL-2.0: https://github.com/Blacktempel/DiskInfoToolkit/tree/25319eae5781e75bcf141e844ceab2afe94d40ea
- RAMSPDToolkit-NDD 1.4.2, MPL-2.0: https://github.com/Blacktempel/RAMSPDToolkit/tree/3b47b960e0830fef344624ad5e389675d5f0a1ce
- BlackSharp.Core 1.0.7, MPL-2.0: https://github.com/Blacktempel/BlackSharp
- Microsoft System.Memory, System.Buffers, System.Numerics.Vectors and System.Runtime.CompilerServices.Unsafe, MIT: https://github.com/dotnet/runtime

MPL-2.0 is included as LibreHardwareMonitor-LICENSE.txt and also applies to the three listed toolkit libraries. Their original package metadata is included alongside that license. HidSharp and Microsoft license texts are included separately.

Upstream license texts are included under Licenses. Microsoft .NET Framework is a Windows component; the application requires .NET Framework 4.8 or newer.

The application icon is based on the PNG supplied by the user. Its black background was removed with imagegen; the transparent variant is resized and packaged into an ICO container. The original PNG is retained in the source project.

PresentMon 2.6.0: Copyright (C) 2017-2024 Intel Corporation; parts also Copyright (c) 2025 NVIDIA CORPORATION & AFFILIATES. MIT license, included as Licenses/PresentMon.txt. Unmodified official x64 console executable is embedded as a resource and verified before extraction/execution. Source and release: https://github.com/GameTechDev/PresentMon/releases/tag/v2.6.0 . SHA256: B2A706BC6AD475749E3B7E3409263AA1E6906D45BDCF993F6DBC0F660188F1AF . It reads Windows graphics presentation events; Brichka does not inject code into the game.

ATK Nearlink 373B:10C9 battery protocol reference: atk-tool-plus, Copyright 2026 Levon Kirakosyan, MIT, https://github.com/papelblume/atk-tool-plus . License included as Licenses/ATK-tool-plus-MIT.txt. Brichka independently sends only the documented battery telemetry request; no configuration, pairing or firmware commands are used.

Battery profile data: razer-battery-report, Copyright 2024 Timofey Gelazoniya, MIT, https://github.com/xzeldon/razer-battery-report . A normalized offline snapshot of the mouse catalog is included; online updates read catalog.rs as data. License: Licenses/razer-battery-report-MIT.txt. No serial-number queries are used.

SONiX keyboard identifier and battery protocol reference: Keyboard Studio, Copyright (c) 2026 donglover69, MIT, https://github.com/donglover69/sonix-keyboard-studio . Online updates read KeyboardModel.cs as identifier data, without executing source code. License: Licenses/Keyboard-Studio-MIT.txt. Brichka implements only the battery exchange, not configuration commands.

PawnIO 2.2.0: unmodified, digitally signed official PawnIO_setup.exe is bundled for optional CPU sensor access. Source: https://github.com/namazso/PawnIO and https://github.com/namazso/PawnIO.Setup/releases/tag/2.2.0 . Driver GPL-2.0-or-later with module exception; modules: https://github.com/namazso/PawnIO.Modules . Installer SHA256: 1F519A22E47187F70A1379A48CA604981C4FCF694F4E65B734AAA74A9FBA3032 . Installation requires Windows administrator approval and is initiated by the CPU access button. The shared driver is retained when Brichka is removed.
# OpenRGB 1.1

RGB uses the separate, unmodified OpenRGB Windows x64 executable over its local SDK. OpenRGB is GPL-2.0-or-later; the license, exact release and corresponding source URL are included in `Licenses/OpenRGB-GPL-2.0.txt` and `Licenses/OpenRGB-source.txt`. Upstream: https://openrgb.org/ . Device photographs are downloaded from their source websites and cached locally; each cached photograph has a `.source` attribution file.

