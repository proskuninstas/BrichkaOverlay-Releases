# Third party components

LibreHardwareMonitor 0.9.6: https://github.com/LibreHardwareMonitor/LibreHardwareMonitor (MPL-2.0). Unmodified upstream binary. Source and license: https://github.com/LibreHardwareMonitor/LibreHardwareMonitor/tree/v0.9.6

The required official release dependency DLLs are distributed unchanged:

- HidSharp 2.6.4, Apache-2.0: https://www.nuget.org/packages/HidSharp/2.6.4
- DiskInfoToolkit 1.1.2, MPL-2.0: https://github.com/Blacktempel/DiskInfoToolkit/tree/25319eae5781e75bcf141e844ceab2afe94d40ea
- RAMSPDToolkit-NDD 1.4.2, MPL-2.0: https://github.com/Blacktempel/RAMSPDToolkit/tree/3b47b960e0830fef344624ad5e389675d5f0a1ce
- BlackSharp.Core 1.0.7, MPL-2.0: https://github.com/Blacktempel/BlackSharp/tree/c70b735c6cec123ee8a046ac4a0bc6c606f52cf0
- Microsoft System.Memory, System.Buffers, System.Numerics.Vectors and System.Runtime.CompilerServices.Unsafe, MIT: https://github.com/dotnet/runtime

MPL-2.0 is included as LibreHardwareMonitor-LICENSE.txt and also applies to the three listed toolkit libraries. Their original package metadata is included alongside that license. HidSharp and Microsoft license texts are included separately.

Upstream license texts are included under Licenses. Microsoft .NET Framework is a Windows component; the application requires .NET Framework 4.8 or newer.

The application icon is based on the PNG supplied by the user. Its black background was removed with imagegen; the transparent variant is resized and packaged into an ICO container. The original PNG is retained in the source project.

PresentMon 2.6.0: Copyright (C) 2017-2024 Intel Corporation; parts also Copyright (c) 2025 NVIDIA CORPORATION & AFFILIATES. MIT license, included as Licenses/PresentMon.txt. Unmodified official x64 console executable is embedded as a resource and verified before extraction/execution. Source and release: https://github.com/GameTechDev/PresentMon/releases/tag/v2.6.0 . SHA256: B2A706BC6AD475749E3B7E3409263AA1E6906D45BDCF993F6DBC0F660188F1AF . It reads Windows graphics presentation events; Brichka does not inject code into the game.

ATK Nearlink 373B:10C9 battery protocol reference: atk-tool-plus, Copyright 2026 Levon Kirakosyan, MIT, https://github.com/papelblume/atk-tool-plus . License included as Licenses/ATK-tool-plus-MIT.txt. Brichka independently sends only the documented battery telemetry request; no configuration, pairing or firmware commands are used.

Battery profile data: razer-battery-report, Copyright 2024 Timofey Gelazoniya, MIT, https://github.com/xzeldon/razer-battery-report . A normalized offline snapshot of the mouse catalog is included; online updates read catalog.rs as data. License: Licenses/razer-battery-report-MIT.txt. No serial-number queries are used.

SONiX keyboard identifier and battery protocol reference: Keyboard Studio, Copyright (c) 2026 donglover69, MIT, https://github.com/donglover69/sonix-keyboard-studio . Online updates read KeyboardModel.cs as identifier data, without executing source code. License: Licenses/Keyboard-Studio-MIT.txt. Brichka implements only the battery exchange, not configuration commands.

PawnIO 2.2.0: the separate installer is NOT bundled starting with Brichka 3.9.0. If needed, the one-time CPU setup downloads the fixed official, unmodified, digitally signed PawnIO_setup.exe directly from https://github.com/namazso/PawnIO.Setup/releases/download/2.2.0/PawnIO_setup.exe and verifies SHA256 1F519A22E47187F70A1379A48CA604981C4FCF694F4E65B734AAA74A9FBA3032 before execution. Upstream source/license: https://github.com/namazso/PawnIO . Driver GPL-2.0-or-later with module exception; modules: https://github.com/namazso/PawnIO.Modules . Installation requires Windows administrator approval. An existing driver is not downloaded again; it is retained when Brichka is removed.

## Дополнительные темы оверлея

Материалы Orbital, Anime Pulse и Apex Motorsport предоставлены пользователем в пакете тем. По описанию пакета это оригинальные сгенерированные элементы интерфейса без сторонних персонажей и логотипов. Используются локальные SVG/PNG и параметры оформления. Системные шрифты Windows не включены в дистрибутив.

## PawnIO и встроенные модули LibreHardwareMonitor

Full GPL-2.0 text: Licenses/PawnIO-GPL-2.0.txt. Original PawnIO copyright and special exception: Licenses/PawnIO-Exception.txt. The exception does not remove the obligation to comply with the GPL for PawnIO. Brichka does not modify the upstream installer downloaded by CPU setup.

LibreHardwareMonitor 0.9.6 includes unmodified signed PawnIO.Modules 0.1.6. Upstream release and sources: https://github.com/namazso/PawnIO.Modules/releases/tag/0.1.6 and https://github.com/namazso/PawnIO.Modules/tree/0.1.6 . Original LGPL-2.1 text: Licenses/PawnIO-Modules-LGPL-2.1.txt. Upstream notices from the exact LibreHardwareMonitor version: Licenses/LibreHardwareMonitor-THIRD-PARTY-NOTICES.txt.

Full corresponding source for the embedded modules is provided offline as Licenses/PawnIO.Modules-0.1.6-source.zip.txt (Base64 encoding of the original archive). Decoding instructions, the exact commit and SHA-256 are in Licenses/PawnIO.Modules-source.txt. An ordinary ZIP is available beside the release assets as PawnIO.Modules-0.1.6-source.zip.

Технический аудит и исторические вопросы прежних сборок: RIGHTS-AUDIT-3.8.0.md в исходном проекте. Изменения 3.9.0 исключают отдельный установщик из нового пакета и добавляют соответствующие исходники встроенных модулей.

Семь дополнительных тем 3.8.0 реализованы геометрическими элементами и нейтральными названиями. В 3.9.0 иконки 13 дополнительных тем адаптированы imagegen по пользовательским примерам в отдельные прозрачные наборы. Игровые логотипы, персонажи, фоновые иллюстрации и постеры не включены. Сведения о происхождении пользовательских картинок не являются гарантией прав третьих лиц.
